package de.hfkbremen.skeleton.examples.advanced;

import processing.core.PApplet;
import processing.core.PVector;
import java.util.ArrayList;

public class SketchSkeletonExampleAdvanced extends PApplet {

   	private ArrayList<PVector> mList = new ArrayList<>();

    public void settings() {
        size(640, 480);
    }

    public void setup() {
    }

    public void draw() {
    }

    public static void main(String[] args) {
        PApplet.main(SketchSkeletonExampleAdvanced.class.getName());
    }
}
