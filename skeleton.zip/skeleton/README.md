# skeleton

a skeleton project for projects
